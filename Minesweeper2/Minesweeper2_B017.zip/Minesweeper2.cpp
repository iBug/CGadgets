#include <iostream>
#include <iomanip>
#include <string>
#include <cstring>
#include <ctime>
#include <cstdlib>
#include <windows.h>
using namespace std;

const char Vers[32] = "Beta 2.0.0.017";

/***********************
**                    **
**  Data & Functions  **
**                    **
***********************/

typedef unsigned char byte;
HANDLE hOut,hIn;
void initConsole();
byte bitByUp(byte,int),bitByDown(byte,int);
bool bitBy(byte,int);
// Control (Actually Input)
namespace Control{
	int GetMouse(COORD&,DWORD&);
	int GetMouseWait(COORD&,DWORD&);
}
namespace Display{
	const unsigned short gdStatusN = 2;
	byte gData[30][24],gStatus[gdStatusN];// For Minesweeper Board and Menu Bar 
	unsigned short gMineLeft,gTime,gTimeMilli,gWidth,gHeight;// For Minesweeper Data
	const char *text;
	void SetMode(int);
	int Proceed(void);// Introduce the newest "Sync" algorithm
}

/****************
**             **
**  Main Game  **
**             **
****************/

namespace Game{
	byte board[30][24];bool gameStarted,win;
	unsigned short mineLeft,mineCount,boardWidth,boardHeight,diff,Time;
	unsigned long mouseBtn,mouseBtnPrev,mouseEvent,boardSize,TimeStart;
	COORD mousePos,mousePosPrev,Pos; signed long k;
	
	/*
	Memory Data Format:
	Bin: 0000 0000
	Higher 4 bits (0xF0):  128 for 'isLocked' (In certain cases, useful. And overwrite 'isUncovered' as well)
							64 for 'isUncovered' (Overwrite 'isMarked')
							32 for 'isMarked' (Overwrite 'isMine')
							16 for 'isMine'
	Lower 4 bits (0x0F): Number of mines around (Range from 0 to 8)
	*/
	
	extern const char *MainMenu,*ConfigMenu;
	bool ShowMainMenu = true;
	const byte boardConf[3][3] = {{9,9,10},{16,16,40},{30,16,99}};
	inline byte& Board(const COORD& Pos){return board[Pos.X][Pos.Y];}
	inline bool isValidPos(const COORD& Pos){return !(Pos.X<0 || Pos.X>=boardWidth || Pos.Y<0 || Pos.Y>=boardHeight);}
	using std::clock;using std::memcpy;int trigger(COORD,int);
	
	void MainMenuScreen(){
		// Clear screen and show main menu
		Display::SetMode(0);
		Display::text = MainMenu;
		Display::Proceed();
		// Wait until a button is clicked
		mouseBtn = 0;mouseEvent = 0;
		for(;;){
			mouseBtnPrev = mouseBtn;
			Control::GetMouseWait(mousePos,mouseBtn);
			if(mouseBtnPrev!=0 && mouseBtn==0)
				if(mousePos.Y>=3 && mousePos.Y<6 && mousePos.X<5)break;
		}
		mouseBtn = mouseBtnPrev = 0;
		diff = mousePos.Y-3;
	}
	int initGame(){
		// Configure Minesweeper Board
		boardWidth = boardConf[diff][0];boardHeight = boardConf[diff][1];
		boardSize = boardWidth*boardHeight;
		mineLeft = mineCount = boardConf[diff][2];
		std::memset(board,0,720);std::memset(Display::gData,0,720);
		mouseBtn = 0;
		Display::gTime = 0;
		Display::gMineLeft = mineLeft;
		Display::gWidth = boardWidth;
		Display::gHeight = boardHeight;
		Display::SetMode(1);
		Display::Proceed();
		// Wait until a click
		mouseBtn = 0;mouseEvent = 0;
		while(mouseBtn!=0 || mouseBtnPrev!=1 || !(isValidPos(Pos) ||(mousePos.X<30 && mousePos.Y==0))){
			mouseBtnPrev = mouseBtn;
			Control::GetMouseWait(mousePos,mouseBtn);
			if(mousePos.Y>0){
				Pos.X = (mousePos.X-(60-2*boardWidth)/2)/2;
				Pos.Y = mousePos.Y-(24-boardHeight)/2-1;
				Display::gStatus[0] = 0;
				Display::gStatus[1] = 0;
			}else{
				if(mousePos.X<30){
					Pos.X = Pos.Y = -32768;
					Display::gStatus[1] = 1;
					Display::gStatus[0] = 0;
				}else{
					Pos.X = Pos.Y = -32767;
					Display::gStatus[0] = 1;
					Display::gStatus[1] = 0;
				}
			}
			Display::Proceed();
		}
		if(mousePos.X<30 && mousePos.Y==0){
			// Return button clicked
			ShowMainMenu = true;
			return 1;
		}
		mousePos = Pos;
		// Deploy mines
		for(signed short i=0;i<9;i++){
			Pos.X = mousePos.X+i%3-1;Pos.Y = mousePos.Y+i/3-1;
			if(isValidPos(Pos))Board(Pos) |= 0x10;
		}
		for(signed short i=0;i<mineCount;i++){
			k = std::rand()%boardSize;
			Pos.X = k%boardWidth;Pos.Y = k/boardWidth;
			if(Board(Pos)&0x10){i--;continue;}
			Board(Pos) |= 0x10;
		}
		for(signed short i=0;i<9;i++){
			Pos.X = mousePos.X+i%3-1;Pos.Y = mousePos.Y+i/3-1;
			if(isValidPos(Pos))Board(Pos) &= ~0x10;
		}
		for(signed short i=0,j=0;i<boardSize;i++){
			k = 0;
			for(j=0;j<9;j++){
				if(j==4)continue;
				Pos.X = i%boardWidth+j%3-1;
				Pos.Y = i/boardWidth+j/3-1;
				if(!isValidPos(Pos))continue;
				if(Board(Pos)&0x10)k++;
			}
			board[i%boardWidth][i/boardWidth] |= (k&0x0F);
		}
		// Completing
		TimeStart = clock(); 
		gameStarted = true;win = false;
		trigger(mousePos,0);
		Display::Proceed();
		return 0;
	}
	int trigger(COORD pos,int Mode){
		/* Parameter "Mode":
		0 - Left Click -> Open
		1 - Right Click -> Flag
		2 - Middle Click -> Open around if correctly flagged
		*/
		if(bitBy(Board(pos),7))return -1;// Bit 'isLocked' is set
		COORD Pos;
		if(Mode == 0){
			if(Board(pos)>=0x20)return 0;
			if(Board(pos)&0x10){
				Board(pos) = bitByUp(Board(pos),7);
				win = false;
				gameStarted = false;
				return 0;
			}
			Board(pos) |= 0x40;
			Display::gData[pos.X][pos.Y] = Board(pos)&0x0F;
			// On discovery of a "Zero"
			if((Board(pos)&0x0F)==0){
				COORD Pos;
				Display::gData[pos.X][pos.Y] = 9;
				for(int k=0;k<9;k++){
					Pos.X = pos.X-1+k%3;Pos.Y = pos.Y-1+k/3;
					if(isValidPos(Pos))if(Board(Pos)<32)trigger(Pos,0);
				}
			}
		}
		if(Mode == 1){
			if(Board(pos)>=64)return 0;
			if(Board(pos)&0x20){
				Board(pos) &= ~0x20;
				Display::gData[pos.X][pos.Y] = 0;
			}
			else{
				Board(pos) |= 0x20;
				Display::gData[pos.X][pos.Y] = 11;
			}
		}
		if(Mode == 2){
			int i;k = 0;
			for(i=0;i<9;i++){
				if(i==4)continue;
				Pos.X = pos.X+i%3-1;Pos.Y = pos.Y+i/3-1;
				if(isValidPos(Pos))if(bitBy(Board(Pos),5))k++;
			}
			if(k!=(Board(pos)&0x0F))return 0;
			for(i=0;i<9;i++){
				if(i==4)continue;
				Pos.X = pos.X+i%3-1;Pos.Y = pos.Y+i/3-1;
				if(isValidPos(Pos))
					if(bitBy(Board(Pos),4)^bitBy(Board(Pos),5)==1){
						win = false;
						gameStarted = false;
						return 0;
				}
			}
			for(i=0;i<9;i++){
				if(i==4)continue;
				Pos.X = pos.X+i%3-1;Pos.Y = pos.Y+i/3-1;
				if(isValidPos(Pos))trigger(Pos,0);
			}
		}
	}
	void Game(){
		if(ShowMainMenu)MainMenuScreen();
		if(initGame()==1)return;
		COORD Pos;bool winchk;
		// A single loop in this 'while' is a single event
		while(gameStarted){
			mouseBtnPrev = mouseBtn;
			mousePosPrev = mousePos;
			Control::GetMouse(mousePos,mouseBtn);
			Display::gTime = (clock()-TimeStart)/1000;
			// Process mouse position
			if(mousePos.Y>0){
				Pos.X = (mousePos.X-(60-2*boardWidth)/2)/2;
				Pos.Y = mousePos.Y-(24-boardHeight)/2-1;
				Display::gStatus[0] = 0;
				Display::gStatus[1] = 0;
			}else{
				if(mousePos.X<30){
					Pos.X = Pos.Y = -32768;
					Display::gStatus[1] = 1;
					Display::gStatus[0] = 0;
				}else{
					Pos.X = Pos.Y = -32767;
					Display::gStatus[0] = 1;
					Display::gStatus[1] = 0;
				}
			}
			// Trigger events
			if(mouseBtn==0){
				if(mouseEvent>3 && isValidPos(Pos))trigger(Pos,2);
				else if(mouseEvent>0 && isValidPos(Pos)){trigger(Pos,mouseEvent-1);}
				else if(mouseEvent==1 && mousePos.Y==0){
					if(mousePos.X<30){
						ShowMainMenu = true;
					}else{
						ShowMainMenu = false;
					}
					mouseBtnPrev = mouseEvent = 0;
					return;
				}
				mouseEvent = 0;
			}
			else{
				mouseEvent |= mouseBtn;
			}
			// Win Check
			winchk = true;
			for(int i=0;i<boardSize;i++){
				Pos.X = i%boardWidth;Pos.Y = i/boardWidth;
				if(!bitBy(Board(Pos),4) && !bitBy(Board(Pos),6)){winchk = false;break;}
			}
			if(winchk){win = true;gameStarted = false;}
			// Completing
			Display::Proceed();
		}
		if(win){
			for(int i=0;i<boardSize;i++){
				Pos.X = i%boardWidth;Pos.Y = i/boardWidth;
				if(bitBy(Board(Pos),4)){Display::gData[Pos.X][Pos.Y] = 11;}
			}
		}else{
			for(int i=0;i<boardSize;i++){
				Pos.X = i%boardWidth;Pos.Y = i/boardWidth;
				if(bitBy(Board(Pos),4) && !bitBy(Board(Pos),5))Display::gData[Pos.X][Pos.Y] = bitBy(Board(Pos),7)?14:10;
				if(bitBy(Board(Pos),5) && !bitBy(Board(Pos),4))Display::gData[Pos.X][Pos.Y] = bitBy(Board(Pos),7)?14:12;
			}
		}
		Display::gTimeMilli = (clock()-TimeStart)%1000;
		Display::Proceed();
		for(;;){
			if(Pos.X==-32768 && Pos.Y==-32768 && mouseBtn==0 && mouseBtnPrev!=0){ShowMainMenu = false;break;}
			if(Pos.X==-32767 && Pos.Y==-32767 && mouseBtn==0 && mouseBtnPrev!=0){ShowMainMenu = true;break;}
			
			mouseBtnPrev = mouseBtn;
			Control::GetMouseWait(mousePos,mouseBtn);
			if(mousePos.Y>0){
				Pos.X = (mousePos.X-(60-2*boardWidth)/2)/2;
				Pos.Y = mousePos.Y-(24-boardHeight)/2-1;
				Display::gStatus[0] = 0;
				Display::gStatus[1] = 0;
			}else{
				if(mousePos.X<30){
					Pos.X = Pos.Y = -32768;
					Display::gStatus[1] = 1;
					Display::gStatus[0] = 0;
				}else{
					Pos.X = Pos.Y = -32767;
					Display::gStatus[0] = 1;
					Display::gStatus[1] = 0;
				}
			}
			Display::Proceed();
		}
	}
	
}

int main(){
	initConsole();
	for(;;)Game::Game();
}

/**************
**           **
**  Library  **
**           **
**************/

void initConsole(){
	// General Initializer
	hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	hIn = GetStdHandle(STD_INPUT_HANDLE);
	DeleteMenu(GetSystemMenu(GetConsoleWindow(),0),SC_MAXIMIZE,MF_DISABLED);
	// Resize Screen
	// Notice: Default Window 80x25, Default Buffer 80x300
	COORD bSize = {60,26};
	SMALL_RECT cSize = {0,0,59,25};
	SetConsoleWindowInfo(hOut,1,&cSize);
	SetConsoleScreenBufferSize(hOut,bSize);
	// Set Title
	char title[64] = "iBug Minesweeper II ";
	SetConsoleTitle(std::strcat(title,Vers));
	// Hide Cursor [_] -> [ ]
	CONSOLE_CURSOR_INFO CCI;GetConsoleCursorInfo(hOut,&CCI);
	CCI.bVisible = 0;SetConsoleCursorInfo(hOut,&CCI);
	// Initialize Randomizer
	srand((unsigned)time(NULL));
}

namespace Display{
	int Mode = 0;unsigned long clsCount = 0;
	byte dData[30][24],dStatus[gdStatusN];
	unsigned short dMineLeft,dTime,dTimeMilli,dWidth,dHeight;
	COORD gMineLeftPos,gTimePos,gTimeMilliPos,gOffset,Pos;
	const char img[256][3] = {"  ","��","��","��","��","��","��","��","��","  ","��","��","��","  ","��","  "};
	//               Meaning: None   1    2    3    4    5    6    7    8  Safe Mine Mark Wrong SP  Mine 
	const WORD imgColor[256]={0x1F,0x2F,0x2F,0x2F,0x2F,0x2F,0x2F,0x2F,0x2F,0x2F,0x4F,0x1F,0xEC,0x00,0xEC,0x00};
	//                Number:   0    1    2    3    4    5    6    7    8    9   10   11   12   13   14   15
	const char btnimg[16][3] = {"��","��"};
	const WORD btnimgColor[16]={0x8E,0x89};
	const WORD btnimgClrBr[16]={0x7E,0x79};
	//                  Number:   0    1
	const COORD btnPos[16] = {{30,0},{28,0}};
	
	void clear(){
		COORD startPos = {0,0};
		FillConsoleOutputCharacter(hOut,0x20,1560,startPos,&clsCount);
		FillConsoleOutputAttribute(hOut,0x0F,1560,startPos,&clsCount);
		SetConsoleCursorPosition(hOut,startPos);
	}
	void SetMode(int newMode){
		Mode = newMode;
		if(newMode==1){
			dWidth = gWidth;dHeight = gHeight;
			dMineLeft = 0;
			dTime = dTimeMilli = 999;
			gTime = gTimeMilli = 0;
			for(int i=0;i<gdStatusN;i++){
				dStatus[i] = 255;
				gStatus[i] = 0;
			}
			gMineLeftPos.X = 0;gMineLeftPos.Y = 0;
			gTimePos.X = 53;gTimePos.Y = 0;
			gTimeMilliPos.X = 56;gTimeMilliPos.Y = 0;
			gOffset.X = (60-2*gWidth)/2;
			gOffset.Y = (24-gHeight)/2;
			std::memset(dData,255,720);
			Pos.X = 29;Pos.Y = 0;
		}
		clear();
	}
	int Proceed(void){
		static int i,j;
		using namespace std;
		switch(Mode){
			case 0:
				clear();
				SetConsoleTextAttribute(hOut,0x0F);
				for(i=0;text[i];i++){
					if(text[i]==0x01){i++;SetConsoleTextAttribute(hOut,text[i]);i++;}
					cout<<text[i];
				}
				break;
			case 1:
				for(int i=0;i<gdStatusN;i++){
					if(dStatus[i] != gStatus[i]){
						SetConsoleCursorPosition(hOut,btnPos[i]);
						SetConsoleTextAttribute(hOut,(dStatus[i]=gStatus[i])==0?btnimgColor[i]:btnimgClrBr[i]);
						cout<<btnimg[i];
					}
				}
				cout<<setfill('0');
				// Print MineLeft and Time 
				SetConsoleTextAttribute(hOut,0x0F);
				if(gMineLeft != dMineLeft){
					SetConsoleCursorPosition(hOut,gMineLeftPos);
					cout<<setw(3)<<(dMineLeft=gMineLeft);
				}
				if((gTime=gTime>999?999:gTime) != dTime){
					SetConsoleCursorPosition(hOut,gTimePos);
					cout<<setw(3)<<(dTime=gTime);
				}
				if(dTimeMilli != gTimeMilli){
					SetConsoleCursorPosition(hOut,gTimeMilliPos);
					cout<<'.'<<setw(3)<<(dTimeMilli=gTimeMilli);
				}
				// Print the board
				cout<<setfill(' ');
				for(j=0;j<dHeight;j++){
					for(i=0;i<dWidth;i++){
						if(dData[i][j]!=gData[i][j]){
							Pos.X = gOffset.X+2*i;Pos.Y = gOffset.Y+j+1;
							SetConsoleCursorPosition(hOut,Pos);
							SetConsoleTextAttribute(hOut,imgColor[gData[i][j]]);
							cout<<setw(2)<<img[gData[i][j]];
							dData[i][j] = gData[i][j];
						}
					}
				}
				break;
		}
	}
}
namespace Control{
	unsigned long readCount = 0,inputCount;
	INPUT_RECORD inRec;
	COORD GetConsoleCursorPosition(HANDLE H){CONSOLE_SCREEN_BUFFER_INFO A;GetConsoleScreenBufferInfo(H,&A);return A.dwCursorPosition;}
	int GetMouse(COORD &Pos,DWORD &btnState){
		GetNumberOfConsoleInputEvents(hIn,(LPDWORD)&inputCount);
		if(inputCount==0)return 1;// Nothing Happened
		ReadConsoleInput(hIn,&inRec,1,&readCount);
		if(inRec.EventType != MOUSE_EVENT)return 2;// Not a Mouse Event
		Pos = inRec.Event.MouseEvent.dwMousePosition;
		btnState = inRec.Event.MouseEvent.dwButtonState;
		return 0;// Well Done
	}
	int GetMouseWait(COORD &Pos,DWORD &btnState){
		ReadConsoleInput(hIn,&inRec,1,&readCount);
		if(inRec.EventType != MOUSE_EVENT)return 2;// Not a Mouse Event
		Pos = inRec.Event.MouseEvent.dwMousePosition;
		btnState = inRec.Event.MouseEvent.dwButtonState;
		return 0;// Well Done
	}
}

namespace Game{
	const char *MainMenu = string("Welcome to iBug Minesweeper II Ver ")
							.append(::Vers)
							.append("\n\nSelect Difficulty:\n")
							.append("\x01\x2F[ 1 ]\x01\x0F Easy\n")
							.append("\x01\x1F[ 2 ]\x01\x0F Medium\n")
							.append("\x01\x4F[ 3 ]\x01\x0F Hard\n")
							.append("Click on your choice.").c_str();
	const char *ConfigMenu = string("Sorry, nothing here.").c_str();
}

inline byte bitByUp(byte a,int n){return a|(1<<n);}
inline byte bitByDown(byte a,int n){return a&~(1<<n);}
inline bool bitBy(byte a,int n){return (a&(1<<n))!=0;}

